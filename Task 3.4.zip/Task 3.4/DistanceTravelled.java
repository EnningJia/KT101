
import java.util.Scanner;

public class DistanceTravelled{
    
    
    // main function which displayed all tasks
     public static void main (String[] args) {

        Scanner sc = new Scanner(System.in);
        double initialvelocity;
        double time;
        double acceleration;
        double distance;
        
        double distance1=distance(0,120,0.07);
        System.out.println("Distance 1: " + distance1 + " m");
        
        double distance2=distance(8.33,120,0);
        System.out.println("Distance 2: " + distance2 + " m");
        
        
       // Collect user input data and calculate the distance
        System.out.print("Input initial velocity (m/s) :");
        initialvelocity = sc.nextDouble();
        System.out.print("Input time (seconds):");
        time = sc.nextDouble();
        System.out.print("Input acceleration (m/s^2)");
        acceleration = sc.nextDouble();
        System.out.println();
        System.out.println("CALULATING...");
        double distance3 = distance(initialvelocity,time,acceleration);
        System.out.println("Distance: " + distance3 + " m");                // Displace calcuated distance based on user's input
     }
     
     // distance calculated method, which used the equation D = vt + 0.5*at^2
         public static double distance(double initialvelocity, double time, double acceleration){
    
             double distance;
             
             distance = initialvelocity * time + 0.5 * acceleration * Math.pow(time,2);
             
             return distance;
         } 


}


      





